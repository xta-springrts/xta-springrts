return {
  name="XTA Mission Editor",
  description='Used for easy placing of mission starting units',
  URL='http://code.google.com/p/xta-springrts/source/browse/#svn%2Ftrunk%2FMissions',
  shortname='XTA',
  version='$VERSION',
  mutator='',
  game='XTA',
  shortGame='XTA',
  modtype=1,
  depend={
    'XTA $VERSION',	--set this to the game name of your choice
  }
}