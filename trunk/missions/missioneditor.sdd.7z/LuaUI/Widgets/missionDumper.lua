
function widget:GetInfo()
	return {
		name      = 'Mission Dumper',
		desc      = 'Stores units/buildings position into a mission template file',
		author    = 'Deadnight Warrior',
		date      = '20 Jul 2012',
		license   = 'GNU GPL v2',
		layer     = 0,
		enabled   = true,
	}
end

--------------------------------------------------------------------------------
-- Speedups
--------------------------------------------------------------------------------
local noFile = true
local file
local fileName = "LuaUI/" .. Game.modShortName .. "_mission_editor_dump.lua"

function widget:Initialize()
	widgetHandler:RegisterGlobal("DumpMission", DumpMission)
end

function DumpMission(textLine)
	if textLine == "BeginDump" and noFile==true then
		file = io.open(fileName, 'w')
		file:write('gameData = {\n\tmap = "' .. Game.mapName .. '",\n\tgame = "' .. Game.modShortName .. '",\n')
		noFile = false
	elseif textLine == "EndDump" and noFile==false then
		file:write("}\n\nreturn gameData, spawnData, missionTriggers, locations, briefing")
		file:flush()
		file:close()
		noFile = true
		Spring.Echo("SpawnData dumped into Spring/" .. fileName)
	elseif noFile==false then
		file:write(textLine)
	end
end