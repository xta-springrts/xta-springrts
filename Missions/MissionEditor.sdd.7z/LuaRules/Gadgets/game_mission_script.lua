function gadget:GetInfo()
  return {
    name      = "Mission Loader",
    desc      = "Loads a mission for further editing",
    author    = "Deadnight Warrior",
    date      = "14 Jul 2012",
    license   = "GNU LGPL, v2 or later",
    layer     = 1,
    enabled   = true --  loaded by default?
  }
end

local spGetTeamInfo = Spring.GetTeamInfo
local spGetGroundHeight = Spring.GetGroundHeight
local spCreateUnit = Spring.CreateUnit
local spCreateFeature = Spring.CreateFeature
local spEcho = Spring.Echo

local modOptions = Spring.GetModOptions()
local gaiaTeamID = Spring.GetGaiaTeamID()
local teams = Spring.GetTeamList()
for i=1, #teams do
	if teams[i] == gaiaTeamID then
		table.remove(teams, i)
		break
	end
end

local floor = math.floor
local abs = math.abs

local gameData, spawnData = {}, {}


if (gadgetHandler:IsSyncedCode()) then

function gadget:Initialize()
	if modOptions and modOptions.mission then
		local mission = "Missions/" .. modOptions.mission ..".lua"
		if VFS.FileExists(mission) then
			gameData, spawnData = include(mission)
			if gameData.game == Game.modShortName and gameData.minVersion <= Game.modVersion then
				if gameData.map ~= Game.mapName then
					spEcho('Mission "' .. modOptions.mission .. "\" was started on a wrong map or you don't have " .. spawnData.map)
					spEcho("Swiching to mission construction mode")
					gadgetHandler:RemoveGadget()
				else
					initTriggers()			-- pre-parse trigger strings
					missionTriggers = nil	-- kill table once not needed
				end
			else
				spEcho('This mission is intended for "' .. gameData.game .. " " .. gameData.minVersion .. '" or newer')
				spEcho("Swiching to mission construction mode")
				gadgetHandler:RemoveGadget()				
			end
		else
			spEcho("Mission parameter incorrect or wrong mission file")
			spEcho("Swiching to mission construction mode")
			gadgetHandler:RemoveGadget()
		end
	else
		gadgetHandler:RemoveGadget()
	end
end

function gadget:GameStart()
	for _, teamID in pairs(teams) do
		-- set start resources, either from mod options or custom team keys
		Spring.SetTeamResource(teamID, "ms", 0)
		Spring.SetTeamResource(teamID, "es", 0)	

		for _, unitData in pairs(spawnData.teams[teamID]) do
			--local x, z = 16*floor((unitData[2]+8)/16), 16*floor((unitData[3]+8)/16)	-- snap to 16x16 grid, fails for odd footprint sizes
			--local x, z = 8*floor((unitData[2]+4)/8), 8*floor((unitData[3]+4)/8)	-- snap to 8x8 grid
			local x, z = unitData[2], unitData[3]	-- don't snap to grid, not needed if mission dumper was used
			local y = spGetGroundHeight(x, z)
			spCreateUnit(unitData[1], x, y, z, unitData[4], teamID)
		end

		local teamOptions = select(7, spGetTeamInfo(teamID))
		local m = teamOptions.startmetal  or modOptions.startmetal  or 1000
		local e = teamOptions.startenergy or modOptions.startenergy or 1000
		if (m and tonumber(m) ~= 0) then
			--Spring.SetUnitResourcing(commanderID, "m", 0)
			Spring.SetTeamResource(teamID, "m", 0)
			Spring.AddTeamResource(teamID, "m", tonumber(m))
		end
		if (e and tonumber(e) ~= 0) then
			--Spring.SetUnitResourcing(commanderID, "e", 0)
			Spring.SetTeamResource(teamID, "e", 0)
			Spring.AddTeamResource(teamID, "e", tonumber(e))
		end
	end
	for _, featureData in pairs(spawnData.features) do
		local y = spGetGroundHeight(featureData[2], featureData[3])
		spCreateFeature(featureData[1], featureData[2], y, featureData[3], featureData[4], featureData[5])
	end
	gadgetHandler:RemoveGadget()	-- we loaded the mission for further editing
end

else	--UNSYNCED

function gadget:Initialize()
	if modOptions and modOptions.mission then
		local mission = "Missions/" .. modOptions.mission ..".lua"
		if VFS.FileExists(mission) then
			gameData, _, _, locations = include(mission)
			if gameData.game == Game.modShortName and gameData.minVersion <= Game.modVersion then
				if gameData.map ~= Game.mapName then
					gadgetHandler:RemoveGadget()
				else
					local i=1
					while i <= #locations do	-- remove from location list all locations that aren't drawn on ground
						if not locations[i].visible or locations[i].visible==false then
							table.remove(locations, i)
						else
							i=i+1
						end
					end
					if #locations == 0 then
						gadgetHandler:RemoveGadget()	-- there are no locations that need drawing
					end
				end
			else
				gadgetHandler:RemoveGadget()
			end
		else
			gadgetHandler:RemoveGadget()
		end
	else
		gadgetHandler:RemoveGadget()
	end
end

function gadget:DrawWorldPreUnit()
	local alpha = abs(spGetGameFrame() % 60 - 30)/30
	gl.LineWidth(10)
	for i=1, #locations do
		local loc = locations[i]
		if loc.RGB then gl.Color(loc.RGB[1], loc.RGB[2], loc.RGB[3], alpha) else gl.Color(1.0, 1.0, 1.0, alpha) end
		if loc.shape=="C" then
			gl.DrawGroundCircle(loc.X, spGetGroundHeight(loc.X, loc.Z), loc.Z, loc.r-3, 24)
		elseif loc.shape=="R" then
			gl.DrawGroundQuad(loc.X1, loc.Z1, loc.X2, loc.Z2)
		end
	end
end

end