function gadget:GetInfo()
  return {
    name      = "Mission Dumper",
    desc      = "Adds a button to Mission Wizzard unit that saves positions of units/buildings into a mission template file",
    author    = "Deadnight Warrior",
    date      = "20 Jul 2012",
    license   = "GNU GPL, v2 or later",
    layer     = 0,
    enabled   = true  --  loaded by default?
  }
end

local GetUnitCommands = Spring.GetUnitCommands
local FindUnitCmdDesc = Spring.FindUnitCmdDesc
local SetUnitBuildspeed = Spring.SetUnitBuildSpeed
local spGetUnitDefID = Spring.GetUnitDefID
local spGetUnitPosition = Spring.GetUnitPosition
local spGetUnitBuildFacing = Spring.GetUnitBuildFacing
local spGetFeatureTeam = Spring.GetFeatureTeam
local spGetFeaturePosition = Spring.GetFeaturePosition
local spGetFeatureHeading = Spring.GetFeatureHeading
local spGetFeatureDefID = Spring.GetFeatureDefID

local gaiaTeamID = Spring.GetGaiaTeamID()

local fortifications = {
	"arm_dragons_teeth_dead",
	"core_dragons_teeth_dead",
	"rock_teeth",
	"arm_floating_dragons_teeth_dead",
	"core_floating_dragons_teeth_dead",
	"arm_fortification_wall_dead",
	"core_fortification_wall_dead",
	"rock_fort",
}

CMD_DUMP = 33554
local DumpCmdDesc = {
  id      = CMD_DUMP,
  type    = CMDTYPE.ICON,
  name    = 'Dump',
  cursor  = 'Dump',
  action  = 'Dump',
  tooltip = 'Store positions of all units/buildings on map into a mission template file',
}

if (gadgetHandler:IsSyncedCode()) then

	local function AddDumpCmdDesc(unitID)
		if (FindUnitCmdDesc(unitID, CMD_DUMP)) then
			return  -- already exists
		end
		local insertID = FindUnitCmdDesc(unitID, CMD.FIRE_STATE) or	123456 -- back of the pack
		Spring.InsertUnitCmdDesc(unitID, insertID + 1, DumpCmdDesc)
	end

	function gadget:AllowCommand(unitID, unitDefID, teamID, cmdID, cmdParams, _)
		if cmdID == CMD_DUMP then
			SendToUnsynced("Dump")
			return false
		end
		return true
	end

	function gadget:UnitCreated(unitID, unitDefID, teamID, builderID)
		if UnitDefs[unitDefID].name == "zzz_mission_wizzard" then
			AddDumpCmdDesc(unitID)
		end
	end

	function gadget:Initialize()
		gadgetHandler:RegisterCMDID(CMD_DUMP)
		for _, unitID in ipairs(Spring.GetAllUnits()) do
			local teamID = Spring.GetUnitTeam(unitID)
			local unitDefID = spGetUnitDefID(unitID)
			gadget:UnitCreated(unitID, unitDefID, teamID)
		end
	end

	function gadget:Shutdown()
		for _, unitID in ipairs(Spring.GetAllUnits()) do
			local cmdDescID = FindUnitCmdDesc(unitID, CMD_DUMP)
			if (cmdDescID) then
				Spring.RemoveUnitCmdDesc(unitID, cmdDescID)
			end
		end
	end

else	--unsynced

	local function StoreSpawnData()
		if (Script.LuaUI('DumpMission')) then
			Spring.Echo("Starting mission dump")
			local textLine = ""
			Script.LuaUI.DumpMission("BeginDump")
			for teamID=0, #Spring.GetTeamList()-1 do
				if teamID ~= gaiaTeamID then
					Script.LuaUI.DumpMission("\t\t[" .. teamID .. "] = {\n")
					for _, unitID in pairs(Spring.GetTeamUnits(teamID)) do
						local unitDefID = spGetUnitDefID(unitID)
						if UnitDefs[unitDefID].name ~= "zzz_mission_wizzard" then
							local x,_,z = spGetUnitPosition(unitID)
							local f = spGetUnitBuildFacing(unitID)
							textLine = '\t\t\t{"' .. UnitDefs[unitDefID].name .. '", ' .. x .. ", " .. z .. ", " .. f .. "},\n"
							Script.LuaUI.DumpMission(textLine)
						end
					end
					Script.LuaUI.DumpMission("\t\t},\n")
				end
			end
			Script.LuaUI.DumpMission("\t},\n\tfeatures = {\n")
			for _, featureID in pairs(Spring.GetAllFeatures()) do
				local fOwnerID = spGetFeatureTeam(featureID)
				if fOwnerID ~= gaiaTeamID then
					local x, _, z = spGetFeaturePosition(featureID)
					local head = spGetFeatureHeading(featureID)
					local fName = FeatureDefs[spGetFeatureDefID(featureID)].name
					textLine = '\t\t{"' .. fName .. '", ' .. x .. ", " .. z .. ", " .. head .. ", " .. fOwnerID .. "},\n"
					Script.LuaUI.DumpMission(textLine)
				end
			end
			Script.LuaUI.DumpMission("EndDump")
		end
	end
	
	function gadget:Initialize()
		gadgetHandler:AddSyncAction('Dump',StoreSpawnData)  
	end

end