return {
  name="Deadnight Warrior's Mission Editor",
  description='Used for easy placing of mission starting units',
  URL='http://code.google.com/p/xta-springrts/source/browse/#svn%2Ftrunk%2FMissions',
  shortname='',
  version='1.0',
  mutator='',
  game='',
  shortGame='',
  modtype=1,
  depend={
    'XTA 9 SVN',	--set this to the game name of your choice
  }
}